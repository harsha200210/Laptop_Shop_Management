create definer = root@localhost event delete_old_deleted_records on schedule
    every '1' DAY
        starts '2024-05-11 19:45:15'
    enable
    do
    DELETE FROM customer WHERE status = 'Delete' AND DATE(now()) < DATE_SUB(NOW(), INTERVAL 1 DAY);

